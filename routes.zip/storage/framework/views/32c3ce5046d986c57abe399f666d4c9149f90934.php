<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-dark text-white'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\deskapp\resources\views/components/button.blade.php ENDPATH**/ ?>