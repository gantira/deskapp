<?php if(session('sent')): ?>
<div class="alert alert-success">
    <i class="icon-copy dw dw-mail"></i>
    <?php echo e(session('sent')); ?>

</div>
<?php endif; ?>

<?php if(session('failure')): ?>
<div class="alert alert-danger">
    <?php echo e(session('failure')); ?>

</div>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <i class="icon-copy fa fa-check-circle" aria-hidden="true"></i>
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\deskapp\resources\views/components/alert-session.blade.php ENDPATH**/ ?>