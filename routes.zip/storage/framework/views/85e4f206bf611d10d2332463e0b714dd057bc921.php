<?php echo $body; ?>

<br/>
<br/>
<?php /**PATH C:\laragon\www\deskapp\resources\views/mail/send-message.blade.php ENDPATH**/ ?>