<?php echo $email['body']; ?>

<?php /**PATH C:\laragon\www\deskapp\resources\views/mail/send-email.blade.php ENDPATH**/ ?>