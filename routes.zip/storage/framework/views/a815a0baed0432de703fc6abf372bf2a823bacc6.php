<div class="d-flex flex-sm-column justify-content-center pt-6">
    <div>
        <?php echo e($logo); ?>

    </div>

    <div class="card shadow-sm bg-white rounded">
        <div class="card-body">
            <?php echo e($slot); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\deskapp\resources\views/components/auth-card.blade.php ENDPATH**/ ?>