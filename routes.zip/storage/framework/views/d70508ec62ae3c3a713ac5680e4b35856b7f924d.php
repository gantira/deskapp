<?php echo $message['body']; ?>

<?php /**PATH C:\laragon\www\deskapp\resources\views/mail/compose-message.blade.php ENDPATH**/ ?>