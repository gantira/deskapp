User ID <?php echo e($nik); ?> sudah teregistrasi, silakan lakukan ubah password di https://kypas.telkom.co.id (intranet) atau
https://portal.telkom.co.id (internet) <br/>
Login menggunakan user id : <?php echo e($nik); ?> dan pwd : <?php echo e($password); ?> <br/>
Bila mengalami kesulitan,silakan menghubungi Service Desk DIT di email it-care@telkom.co.id
<br/><br/><br/>
<?php /**PATH C:\laragon\www\deskapp\resources\views/mail/user-registered.blade.php ENDPATH**/ ?>