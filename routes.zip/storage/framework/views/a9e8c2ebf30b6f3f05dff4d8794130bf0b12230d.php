<?php if(session('sent')): ?>
<div class="alert alert-success">
    <i class="icon-copy dw dw-mail"></i>
    <?php echo e(session('sent')); ?>

</div>
<?php endif; ?>

<?php if(session('failure')): ?>
<div class="alert alert-danger">
    <?php echo e(session('failure')); ?>

</div>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <i class="icon-copy dw dw-checked"></i>
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('info')): ?>
<div class="alert alert-info">
    <i class="icon-copy fa fa-info-circle" aria-hidden="true"></i>
    <?php echo session('info'); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\deskapp\resources\views/components/alert-message.blade.php ENDPATH**/ ?>