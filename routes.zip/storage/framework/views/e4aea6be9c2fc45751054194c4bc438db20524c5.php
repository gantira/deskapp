<?php echo $body; ?>

<?php /**PATH C:\laragon\www\deskapp\resources\views/mail/send-raw-message.blade.php ENDPATH**/ ?>