<?php return array (
  'admin-component' => 'App\\Http\\Livewire\\AdminComponent',
  'emails.batch-list' => 'App\\Http\\Livewire\\Emails\\BatchList',
  'emails.batch-view' => 'App\\Http\\Livewire\\Emails\\BatchView',
  'emails.compose' => 'App\\Http\\Livewire\\Emails\\Compose',
  'emails.email-list' => 'App\\Http\\Livewire\\Emails\\EmailList',
  'tables.approval-list' => 'App\\Http\\Livewire\\Tables\\ApprovalList',
  'tables.contractor-list' => 'App\\Http\\Livewire\\Tables\\ContractorList',
  'tables.employee-list' => 'App\\Http\\Livewire\\Tables\\EmployeeList',
);